# ---------------------------------------------------------------------------
# Author: Om Bhatt

import winsound 
# This function converts 24hr format into 12 hr format
def convert24hrTo12(num24hr):
    if num24hr < 0: 
        print ("Input Out Of Range :'( - Time cannot be negative!!")
    elif num24hr > 24: 
        print ("Input Out Of Range :'( - Time cannot be greater than 25!!")
    elif num24hr > 12:
        output = num24hr - 12
        return output
    else:
        output = num24hr
        return output

winsound.PlaySound("Timemusic.wav", winsound.SND_ASYNC)
print("---- Welcome To The Time Hour Converter! ----\n")

i = 0
while(i<6):
    A = input("Enter a number to convert it to 12 hour format from 24 hour format: ")
    a = convert24hrTo12(int(A))
    print("Your converted number in 12 hour format is:",a)
    print("\n")
    i = i + 1
print("Thank You For Using Our Converter!")
# ---------------------------------------------------------------------------